from django.db import models

class Filim(models.Model):
    title=models.CharField(max_length=50)

    year=models.PositiveIntegerField()

    genre=models.CharField(max_length=40)

    director=models.CharField(max_length=30)

    tags=models.CharField(max_length=30)

    songs_count=models.PositiveIntegerField()

    language=models.CharField(max_length=35)

    is_trending=models.BooleanField()

    def __str__(self):

        return self.title



# Create your models here.
