from django.shortcuts import render,redirect

from django.views.generic import View

from myapp.models import Filim

class FilimlistView(View):

    def get(self,request,*args,**kwargs):

        qs=Filim.objects.all()

        

        return render(request,"filims_list.html",{"filims":qs})

#filimworld create
#localhost\800\add
#method :post

class FilimCreateView(View):

    def get(self,request,*args,**kwargs):

        return render(request,"filim_create.html")
    
    def post(self,request,*args,**kwargs):

        title_box=request.POST.get('titleBox')

        year_box=request.POST.get('yearBox')

        genre_box=request.POST.get('genreBox')

        director_box=request.POST.get('directorBox')

        tag_box=request.POST.get('tagBox')

        songscount_box=request.POST.get('songBox')

        languague_box=request.POST.get('languagueBox')

        trending_box=request.POST.get('trendingBox')

        #for database adding orm query

        Filim.objects.create(title=title_box,
                             year=year_box,
                             genre=genre_box,
                             director=director_box,
                             tags=tag_box,
                             songs_count=songscount_box,
                             language=languague_box,
                             is_trending=trending_box)
        

        return redirect('filims-list')

#id calling
#url:localhost/800/filim/id(2)
#method :get

class FilimDetialView(View):

    def get(self,request,*args,**kwargs):

        id=kwargs.get('pk')

        #geting a data using id orm query

        qs=Filim.objects.get(id=id)

        return render(request,'filim_detail.html',{'filim':qs})

#delete
#url:8000/filim/remove/
#method :get post

class FilimDeleteView(View):

    def get(self,request,*args,**kwargs):

        id=kwargs.get("pk")

        Filim.objects.get(id=id).delete()

        return redirect('filims-list')
    
#update
#url:800/filim/<int:pk>/change/
#method :get post

class FilimUpdateView(View):

    def get(self,request,*args,**kwargs):

        id=kwargs.get('pk')

        filim_obj=Filim.objects.get(id=id)

        return render(request,'filim_update.html',{'filim':filim_obj})
    
    def post(self,request,*args,**kwargs):

        id=kwargs.get('pk')

        Filim.objects.filter(id=id).update(title=request.POST.get("title"),
                                           year=int(request.POST.get("year")),
                                           genre=request.POST.get("genre"),
                                           director=request.POST.get("director"),
                                           tags=request.POST.get("tags"),
                                           songs_count=int(request.POST.get("songs_count")),
                                           language=request.POST.get("language"),
                                           is_trending=request.POST.get("is_trending"))
        
        return redirect('filims-list')

    

























        
    
    
    




