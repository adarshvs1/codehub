from django.shortcuts import render,redirect

from django.views.generic import View

from myapp.forms import TodolistForm , RegistrationForm ,LoginForm

from myapp.models import Todolist

from django.utils import timezone

from django.contrib.auth import authenticate,login

from django.contrib import messages

# Create your views here.

class TodoCreateView(View):

    def get(self,request,*args,**kwargs):

        form_instance=TodolistForm()

        qs=Todolist.objects.filter(owner=request.user)

        current_month=timezone.now().month

        current_year=timezone.now().year

        qs=Todolist.objects.filter(created_date__month=current_month,
                                   created_date__year=current_year,
                                   owner=request.user)
        
        count=Todolist.objects.filter('pending'==False).count()

        return render(request,'todo_add.html',{'form':form_instance,'tasks':qs,'counts':count})
    
    def post(self,request,*args,**kwargs):

        form_instance=TodolistForm(request.POST)

        if form_instance.is_valid():

            form_instance.instance.owner=request.user

            form_instance.save()

            return redirect('add-todo')
        
        else:

            return render(request,'todo_add.html',{'form':form_instance})
        

#todo Update View

class TodoUpdateView(View):

    def get(self,request,*args,**kwargs):

        id=kwargs.get('pk')

        to_obj=Todolist.objects.get(id=id)

        form_instance=TodolistForm(instance=to_obj)

        return render(request,'todo_edit.html',{'form':form_instance})
    
    def post(self,request,*args,**kwargs):

        id=kwargs.get('pk')

        to_obj=Todolist.objects.get(id=id)

        form_instance=TodolistForm(request.POST,instance=to_obj)

        if form_instance.is_valid():

            form_instance.save()

            return redirect('add-todo')
        
        else:
        
            return render(request,'todo_edit.html',{'form':form_instance})
        

#Delete Todo

class TodoDeleteView(View):

    def get(self,request,*args,**kwargs):

        id=kwargs.get('pk')

        Todolist.objects.get(id=id).delete()

        return redirect('add-todo')
    


#registration

class SignUpView(View):

    def get(self,request,*args,**kwargs):

        form_instance=RegistrationForm()

        return render(request,'register.html',{'form':form_instance})
    
    def post(self,request,*args,**kwargs):

        form_instance=RegistrationForm(request.POST)

        if form_instance.is_valid():

            form_instance.save()

            messages.success(request,'Signup successfully')

            print('account created successfully')

            return redirect('login')
        
        else:

            print('failed to create')

            messages.error(request,'failed to create account')

            return render(request,'register.html',{'form':form_instance})
        

#login

class SignInView(View):

    def get(self,request,*args,**kwargs):

        form_instance=LoginForm()

        return render(request,'login.html',{'form':form_instance})
    
    def post(self,request,*args,**kwargs):

        form_instance=LoginForm(request.POST)

        if form_instance.is_valid():

            data=form_instance.cleaned_data

            user_obj=authenticate(request,**data)

            if user_obj:

                login(request,user_obj)

                messages.success(request,'Login Success')

                return redirect('add-todo')
            
        messages.error(request,'failed to Login')   
            
        return render(request,'login.html',{'form':form_instance})
    
#logout

class SignOutView(View):

    def get(self,request,*args,**kwargs):

        return redirect('login')





