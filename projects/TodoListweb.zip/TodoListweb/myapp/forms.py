from django import forms

from django.contrib.auth.forms import UserCreationForm

from django.contrib.auth.models import User

from myapp.models import Todolist


class TodolistForm(forms.ModelForm):

    class Meta:

        model=Todolist

        fields=['title','status_method']

        widges={

            'title':forms.TextInput(attrs={'class':'form-control'}),

            'status_method':forms.Select(attrs={'class':'form-control'})

            

            
        }
class TodoFilterForm(forms.Form):

    start_date=forms.DateField(widget=forms.DateInput(attrs={'type':'date','class':'form-control'}))

    end_date=forms.DateField(widget=forms.DateInput(attrs={'type':'date','class':'form-control'}))

class RegistrationForm(UserCreationForm):

    class Meta:

        model= User

        fields= ['username','email','password1','password2']


class LoginForm(forms.Form):

    username=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control mb-3'}))

    password=forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control mb-3'}))