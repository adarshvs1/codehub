from django.forms import BaseModelForm
from django.http import HttpResponse
from django.shortcuts import render,redirect

from django.urls import reverse_lazy #is used to redirect

from django.views.generic import View,TemplateView,UpdateView,CreateView

from store.forms import SignUpForm, SignInForm,UserprofileForm,ProjectForm

from django.contrib.auth import login,logout,authenticate

from store.models import UserProfile,Project

from django.urls import reverse_lazy


# Create your views here.


#registration

class SignUpView(View):

    def get(self,request,*args,**kwargs):

        form_instance=SignUpForm()

        return render(request,'store/signup.html',{'form':form_instance})
    
    def post(self,request,*args,**kwargs):

        form_instance=SignUpForm(request.POST)

        if form_instance.is_valid():

            form_instance.save()

            return redirect('signin')
        
        else:

            return render(request,'store/signup.html',{'form':form_instance})
        
#login

class SignInView(View):

    def get(self,request,*args,**kwargs):

        form_instance=SignInForm

        return render(request,'store/login.html',{'form':form_instance})
    
    def post(self,request,*args,**kwargs):

        form_instance=SignInForm(request.POST)

        if form_instance.is_valid():

            data=form_instance.cleaned_data

            user_obj=authenticate(request,**data)

            if user_obj:

                login(request,user_obj)

                return redirect('index')
            
            else:
                
                return render(request,'store/login.html',{'form':form_instance})
            

# indexpage view

class IndexView(View):  #is used for html template

    template_name='store/index.html'

    def get(self,request,*args,**kwargs):

        qs=Project.objects.all().exclude(owner=request.user)

        return render(request,self.template_name,{'projects':qs})


#profile edit


class UserProfileUpdateView(UpdateView):

    model=UserProfile

    form_class=UserprofileForm

    template_name='store/profile_edit.html'

    success_url=reverse_lazy('index')

    #def get(self,request,*args,**kwargs):

        #id=kwargs.get('pk')

        #profile_obj=UserProfile.objects.get(id=id)

        #form_instance=UserprofileForm(instance=profile_obj)

        #return render(request,'store/profile_edit.html',{'form':form_instance})


#create view

class ProjectCreateView(CreateView):

    model=Project

    form_class=ProjectForm

    template_name='store/project_add.html'

    success_url=reverse_lazy('index')

    #if you want to add extra operation  before saving is used form_valid

    def form_valid(self, form):

        form.instance.owner=self.request.user

        return super().form_valid(form)
    
    
#Project List

class MyprojectListView(View):

    def get(self,request,*args,**kwargs):
       

       # qs=Project.objects.filter(owner=request.user)

       qs=request.user.projects.all()
       
       return render(request,'store/myprojects.html',{'works':qs})
    
    
#project delete 

class ProjectDeleteView(View):

    def get(self,request,*args,**kwargs):

        id=kwargs.get('pk')

        Project.objects.get(id=id).delete()

        return redirect('myworks')

    




            



       









