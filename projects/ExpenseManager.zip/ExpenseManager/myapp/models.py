from django.db import models

# importing user model

from django.contrib.auth.models import User



#models:category , transactions


class category(models.Model):

    name =models.CharField(max_length=200)

    budget =models.PositiveBigIntegerField()

    owner =models.ForeignKey(User,on_delete=models.CASCADE)

    image=models.ImageField(upload_to='catimages',default='/catimages/default.png')

    class Meta:

        unique_together=('name','owner')  #used to avoid duplication of category

    def __str__(self):

        return self.name   
    

class Transaction(models.Model):

    title =models.CharField(max_length=200)

    amount =models.PositiveBigIntegerField()

    category_object =models.ForeignKey(category,on_delete=models.CASCADE)

    payment_option=(
        ('cash','cash'),
        ('upi','upi'),
        ('card','card')
    )

    payment_method =models.CharField(max_length=200,choices=payment_option,default='cash')

    created_date=models.DateTimeField(auto_now_add=True)

    owner=models.ForeignKey(User,on_delete=models.CASCADE)

    def __str__(self):
        return self.title




    


