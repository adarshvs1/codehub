from django.shortcuts import render,redirect

from django.views.generic import View

from myapp.forms import CategoryForm,TransacationForm,TransactionFilterForm,RegistrationForm,LoginForm

from myapp.models import category,Transaction

from django.utils import timezone

from django.db.models import Sum

from django.contrib.auth import authenticate,login

from django.contrib import messages

from myapp.decorators import signin_required

from django.utils.decorators import method_decorator

#function dec => method decorator

#@method_decorator(signin_required,name=dispatch (get,post))

@method_decorator(signin_required,name='dispatch')
class CategoryCreateView(View):

    def get(self,request,*args,**kwargs):

        if not request.user.is_authenticated:

            messages.error(request,'invalid session')

            return redirect('signin')
        
        form_instance=CategoryForm(user=request.user)

        #taking loged user details

        qs=category.objects.filter(owner=request.user)

        return render(request,'category_add.html',{'form':form_instance,'categories':qs})
    
    def post(self,request,*args,**kwargs):

        if not request.user.is_authenticated:  

            messages.error(request,'invalid session')

            return redirect('signin')
        

        form_instance=CategoryForm(request.POST,user=request.user,files=request.FILES) #passing the user 

        if form_instance.is_valid():
           
            form_instance.instance.owner=request.user
                
            form_instance.save()

            return redirect('category-add')
        
        else:

            return render(request,'category_add.html',{'form':form_instance})
        
#url:localhost/800/category/{<int:pk>}/change/

@method_decorator(signin_required,name='dispatch')
class CategoryUpdateView(View):

    def get(self,request,*args,**kwargs):

        id=kwargs.get('pk')

        category_object=category.objects.get(id=id)

        form_instance=CategoryForm(instance=category_object)

        return render(request,'category_edit.html',{'form':form_instance})
    
    def post(self,request,*args,**kwargs):

        id=kwargs.get('pk')

        cat_obj=category.objects.get(id=id)

        form_instance=CategoryForm(request.POST,instance=cat_obj)

        if form_instance.is_valid():

            form_instance.save()

            return redirect('category-add')
        else:

            return render(request,'category_edit.html',{'form':form_instance})
        

#transaction view
#method:get post
@method_decorator(signin_required,name='dispatch')
class TransactionCreateView(View):

    def get(self,request,*args,**kwargs):

        form_instance=TransacationForm()

        cur_month=timezone.now().month

        cur_year=timezone.now().year

        categories=category.objects.filter(owner=request.user)  #used to get user

        qs=Transaction.objects.filter(created_date__month=cur_month,created_date__year=cur_year,owner=request.user)

        return render(request,'transaction_add.html',{'form':form_instance,'transactions':qs,'categories':categories})
    
    def post(self,request,*args,**kwargs):

        form_instance=TransacationForm(request.POST)

        if form_instance.is_valid():

            form_instance.instance.owner=request.user #instance=model

            form_instance.save()

            return redirect('transaction-add')
        
        else:

            return render(request,'transaction_add.html',{'form':form_instance})
        
#url:lh/800/transactions/<int:pk>/change/

@method_decorator(signin_required,name='dispatch')
class TransactionUpdateView(View):

    def get(self,request,*args,**kwargs):

        id=kwargs.get('pk')

        trans_obj=Transaction.objects.get(id=id)

        form_instance=TransacationForm(instance=trans_obj)

        return render(request,'transaction_edit.html',{'form':form_instance})
    
    def post(self,request,*args,**kwargs):

        id=kwargs.get('pk')

        trans_obj=Transaction.objects.get(id=id)

        form_instance=TransacationForm(request.POST,instance=trans_obj)

        if form_instance.is_valid():

            form_instance.save()

            return redirect('transaction-add')
        
        else:

            return render(request,'transaction_edit,html',{'form':form_instance})
        
#delete view

@method_decorator(signin_required,name='dispatch')
class TransactionDeleteView(View):

    def get(self,request,*args,**kwargs):

        id=kwargs.get('pk')

        Transaction.objects.get(id=id).delete()

        return redirect('transaction-add')
    
#expense summary view
@method_decorator(signin_required,name='dispatch')
class ExpenseSummaryView(View):

    def get(self,request,*args,**kwargs):

        cur_month=timezone.now().month

        cur_year=timezone.now().year
        
        qs=Transaction.objects.filter(created_date__month=cur_month,
                                      created_date__year=cur_year,
                                      owner=request.user)

        total_expense=qs.values('amount').aggregate(total=Sum('amount'))

        cateogry_summary=qs.values('category_object__name').annotate(total=Sum('amount'))

        payment_summary=qs.values('payment_method').annotate(total=Sum('amount'))

        
        data={

            'total_expense':total_expense.get('total'),

            'cateogry_summary':cateogry_summary,

            'payment_summary':payment_summary
        }

        return render(request,'expense_summary.html',data)
    
#transactionsummary view

class TransactionSummaryView(View):

    def get(self,request,*args,**kwargs):

        form_instance=TransactionFilterForm()

        current_month=timezone.now().month

        current_year=timezone.now().year

        if 'start_date' in request.GET and 'end_date' in request.GET:

            start_date=request.GET.get('start_date')

            end_date=request.GET.get('end_date')

            qs=Transaction.objects.filter(created_date__range=(start_date,end_date))

        else:

            qs=Transaction.objects.filter(created_date__month=current_month,created_date__year=current_year)
            
        return render(request,'transaction_summary.html',{'transactions':qs,'form':form_instance})
    
#chart view

class ChartView(View):

    def get(self,request,*args,**kwargs):

        return render(request,"chart.html")
    
    
#loginpage (registration)

class SignUpView(View):

    def get(self,request,*args,**kwargs):

        form_instance=RegistrationForm()

        return render(request,'register.html',{'form':form_instance})
    
    def post(self,request,*args,**kwargs):

        form_instance=RegistrationForm(request.POST)

        if form_instance.is_valid():

            form_instance.save()

            messages.success(request,"signup successfully !")

            print('account created successfully')

            return redirect('signin')
        else:

            messages.error(request,'faild to create account')

            return render(request,'register.html',{'form':form_instance})

#login

class SignView(View):

    def get(self,request,*args,**kwargs):

        form_instance=LoginForm()

        return render(request,'login.html',{'form':form_instance})
    
    def post(self,request,*args,**kwargs):

        #step1 extract username ,password from loginform

        form_instance=LoginForm(request.POST)

        if form_instance.is_valid():

            data=form_instance.cleaned_data #(usernmae:django,password:password@123)

            #step2 authenticate

            user_obj=authenticate(request,**data)

            #step 3 login/summary

            if user_obj:

                login(request,user_obj)

                messages.success(request,'signin successfull')

                return redirect('summary')
            
            messages.success(request,'signin unsccessfull')
        
            
        return render(request,'login.html',{'form':form_instance})
    
#Logout view

class SignOut(View):

    def get(self,request,*args,**kwargs):

        return redirect('signin')
    



       
        

      







    
    

    









            



     




        
    

    
    

